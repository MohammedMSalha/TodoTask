<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="container">
                    <div class="row mb-3 mt-3">
                    <h4>To view the tasks, please choose the category from the left side.</h4>

                        <div class="col-md-5 mt-3">
                        <?php if($cat->count() > 0): ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item <?php if( request()->id==$data->id){ echo 'active'; } ?>"><a class="btn  <?php if( request()->id==$data->id){ echo 'text-white'; } ?>" href="<?php echo e(route('dashboard-cat',$data->id)); ?>" ><?php echo e($data->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        </div>
                        <div class="col-md-7 mt-3">
                        <?php if($tasks->count()!=0): ?>
                        <div id="accordion">
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                <h5 class="mb-0">
                                    <button class="btn" data-toggle="collapse" data-target="#collapse<?php echo e($data->id); ?>" aria-expanded="false" >
                                        <?php echo e($data->title); ?>

                                    </button>
                                </h5>
                                </div>

                                <div id="collapse<?php echo e($data->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($data->id); ?>" data-parent="#accordion">
                                <div class="card-body">
                                  
                                    <h6 class="mt-2 text-danger">Due Date : </h6><span><?php echo e($data->due_date); ?></span>
                                    <h6 class="mt-2 text-danger">Description : </h6><span><?php echo e($data->due_date); ?></span>
                                    <h6 class="mt-2 text-danger">Tags : </h6><span><?php echo e($data->tags); ?></span>
                        
                                </div>
                                </div>
                            </div>
   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
<div class="col-md-7 mt-3">
    <h6>No Tasks Founded !</h6>
</div>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\Todo task\task\resources\views//dashboard-cat.blade.php ENDPATH**/ ?>