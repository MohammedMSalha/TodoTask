<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <div class="container">
              <div class="row mb-3 mt-3">
            <div class="col-md-4 ">
               <form method="post" action="<?php echo e(route('tasks')); ?>"> 
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <?php if($cat->count() > 0): ?>
  <div class="form-group">
    <label for="exampleInputEmail1">Task title*</label>

    <input type="text" class="form-control" name="title" aria-describedby="name" placeholder="Enter Task Title !" required>
    <?php if($errors->any()): ?>
    <div class="form-group mt-4">
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h6><?php echo e($error); ?></h6>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
</div>
<?php endif; ?>


  </div>
  <div class="form-group mt-3">
  <label for="desc">Task Description*</label>
  <textarea class="form-control" name="desc" rows="3"></textarea>
  </div>
  <div class="form-group mt-3">
  <label for="desc">Category*</label>
  <select class="form-control" name="cat" id="cat" data-parsley-required="true" required>
          <option value="" disabled selected>Choose</option>
          <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <option value="<?php echo e($sn->id); ?>"><?php echo e($sn->title); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        <div class="form-group mt-3">
          <label for="tags">Due Date*</label>
          <input class="form-control" type="date" name="due" id="example-date-input" required>
        </div>
        <div class="form-group mt-3">
          <label for="tags">Tags (Optional)</label>
          <input type="text" data-role="tagsinput" class="form-control" name="tags">
        </div>
 
  <div class="form-group mt-3">
  <button type="submit" class="btn btn-success">ADD</button>
  </div>
  <?php if(session('success')): ?>
<div class="form-group mt-4">
    <div class="alert alert-success">
    <?php echo e(session('success')); ?>

    </div>
    </div>
<?php endif; ?>
  <?php else: ?> 
  <div class="form-group mt-4">
<div class="alert alert-danger">
    <h6>Please, add at least one category ^^</h6>
</div>
        <?php endif; ?>
</form>
</div>
<div class="col-md-8 mt-4 text-center">
<?php if($tasks->count() > 0): ?>
  <table class="table">
    <thead class="thead-light">
      <tr>
        <th scope="col">Title</th>
        <th scope="col">Category</th>
        <th scope="col">Due Date</th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

      <tr>
        <th scope="row"><?php echo e($sn->title); ?></th>
        <td>
        <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($c->id==$sn->cat_id): ?>
                <?php echo e($c->title); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td> 
        <td><?php echo e($sn->due_date); ?></td>
        <td><a href="<?php echo e(route('edit-task', $sn->id)); ?>" class="btn btn-primary">Edit</a></td>
        <td><a href="<?php echo e(route('delete-task', $sn->id)); ?>" class="btn btn-danger">Delete</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php endif; ?>
          </div>
</div>

</div>
</div>
            </div>
            
       

     
    </div>
 
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\Todo task\task\resources\views//tasks/add.blade.php ENDPATH**/ ?>