<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <div class="container">
            <div class="row mb-3 mt-3">
               <form method="post" action="<?php echo e(route('delete-cat',$cat->id)); ?>"> 
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <input type="hidden" name="_method" value="DELETE">
<h4>Are you sure to delete the category?</h4>
               <?php if($cat->count() > 0): ?>
  <div class="form-group">
    <label for="exampleInputEmail1">Category title*</label>
    <input type="text" class="form-control" name="name" value="<?php echo e($cat->title); ?>" aria-describedby="name"  disabled>
    <?php if($errors->any()): ?>
    <div class="form-group mt-4">
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h6><?php echo e($error); ?></h6>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
</div>
<?php endif; ?>


  </div>
  
  
 
  <div class="form-group mt-3">
  <button type="submit" class="btn btn-danger">Delete</button>
  </div>
  <?php if(session('success')): ?>
<div class="form-group mt-4">
    <div class="alert alert-success">
    <?php echo e(session('success')); ?>

    </div>
    </div>
<?php endif; ?>
  <?php else: ?> 
  <div class="form-group mt-4">
<div class="alert alert-danger">
    <h6>Please, add at least one category ^^</h6>
</div>
        <?php endif; ?>
</form>
</div>
 
</div>

            </div>
            
        </div>

     
    </div>

 
 
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\Todo task\task\resources\views//category/delete.blade.php ENDPATH**/ ?>